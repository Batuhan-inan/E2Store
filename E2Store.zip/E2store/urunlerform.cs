﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class urunlerform : Form
    {

        public urunlerform()
        {
            InitializeComponent();
        }
        public void urunleriyenile()
        {
            try
            {
                using (var db = new E2storeDBEntities())
                {
                    var urunlistesi = db.Urunler.Select(s => new { id = s.UrunID, urunlistesi = s.UrunListesi, adet = s.Adet, kategori = s.Kategoriler.KategoriAd }).ToList();
                    urunlerlistesidgw.DataSource = urunlistesi;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ürünler veritabanına bağlanılamadı");
            }
        }
        private void urunlerform_Load(object sender, EventArgs e)
        {
            urunleriyenile();
            urunlerlistesidgw.CellClick += urunlerlistesidgw_CellClick;//cellclick ekleme
            if (KullaniciOturum.GirisYapanKullaniciAdi != "admin")
            {
                stokguncellebtn.Enabled = false;
                uruneklebtn.Enabled = false;
                urunsilbtn.Enabled = false;

                stokguncellebtn.Visible = false;
                urunsilbtn.Visible = false;
                uruneklebtn.Visible = false;
            }
            else
            {
                stokguncellebtn.Enabled = true;
                uruneklebtn.Enabled = true;
                urunsilbtn.Enabled = true;

                stokguncellebtn.Visible = true;
                urunsilbtn.Visible = true;
                uruneklebtn.Visible = true;
            }
            try
            {
                using (var db = new E2storeDBEntities())
                {
                    var kategoriler = db.Kategoriler.Select(k => k.KategoriAd).ToList();
                    filtrelecb.Items.Clear();
                    filtrelecb.Items.AddRange(kategoriler.ToArray());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("veritabanına bağlanılamadı");
            }





        }
        private void urunlerlistesidgw_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (urunlerlistesidgw.SelectedRows.Count > 0)
            {
                int secilenID = Convert.ToInt32(urunlerlistesidgw.SelectedRows[0].Cells["ID"].Value);

                using (var db = new E2storeDBEntities())
                {
                    var urun = db.Urunler.FirstOrDefault(s => s.UrunID == secilenID);
                    if (urun != null)
                    {
                        uruncb.Items.Clear();
                        int limit = Math.Min(urun.Adet, 5);

                        for (int i = 1; i <= limit; i++)
                        {
                            uruncb.Items.Add(i);
                        }

                        if (limit > 0)
                            uruncb.SelectedIndex = 0;
                    }
                }
            }
        }//satır secildiği anda combox değişsin istediğim ve event kısmında cellclick bulamadıgım için elle ekledim


        private void uruneklebtn_Click(object sender, EventArgs e)
        {
            urunekle urunekle = new urunekle();
            urunekle.Owner = this;//yenile fonksıyonuna erişmek için 
            urunekle.Show();
        }

        private void yenilebtn_Click(object sender, EventArgs e)
        {
            urunleriyenile();
        }

        private void urunsilbtn_Click(object sender, EventArgs e)
        {
            if (urunlerlistesidgw.SelectedRows.Count > 0)
            {
                int secilenid = Convert.ToInt32(urunlerlistesidgw.SelectedRows[0].Cells["ID"].Value);
                using (var db = new E2storeDBEntities())
                {
                    var silinecek = db.Urunler.FirstOrDefault(s => s.UrunID == secilenid);
                    if (silinecek != null)
                    {
                        db.Urunler.Remove(silinecek);
                        db.SaveChanges();
                        MessageBox.Show("Ürün silindi.");
                        urunleriyenile(); // tabloyu yenile
                    }
                }

            }
            else
            {
                MessageBox.Show("Lütfen silinecek satırı seçin");
            }
        }

        private void stokguncellebtn_Click(object sender, EventArgs e)
        {
            if (urunlerlistesidgw.SelectedRows.Count > 0)
            {
                stokguncelle stokguncelle = new stokguncelle();
                stokguncelle.Owner = this;//yenile fonksıyonuna erişmek için 
                stokguncelle.Show();
                int secilensatir = Convert.ToInt32(urunlerlistesidgw.SelectedRows[0].Cells["ID"].Value);
                try
                {
                    using (var db = new E2storeDBEntities())
                    {
                        var urun = db.Urunler.FirstOrDefault(s => s.UrunID== secilensatir);
                        if (urun != null)
                        {
                            KullaniciOturum.ID = urun.UrunID;
                        }
                        else
                        {
                            MessageBox.Show("Seçilen ürün veritabanında bulunamadı.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Databaseye bağlanılamadı");
                }
            }
            else
            {
                MessageBox.Show("Satır seçilmedi lütfen satır seçiniz");
            }

        }

        private void satinalbtn_Click(object sender, EventArgs e)
        {

            if (uruncb.SelectedItem != null && urunlerlistesidgw.SelectedRows.Count > 0)
            {
                int alinacakAdet = Convert.ToInt32(uruncb.SelectedItem);
                int secilenID = Convert.ToInt32(urunlerlistesidgw.SelectedRows[0].Cells["ID"].Value);

                using (var db = new E2storeDBEntities())
                {
                    var urun = db.Urunler.FirstOrDefault(x => x.UrunID == secilenID);

                    if (urun != null)
                    {
                        if (urun.Adet >= alinacakAdet)
                        {
                            urun.Adet -= alinacakAdet;
                            db.SaveChanges();

                            MessageBox.Show(alinacakAdet + " adet \"" + urun.UrunListesi + "\" satın alındı.");

                            urunleriyenile(); // DataGridView’i yenile
                            uruncb.Items.Clear(); // Seçim sonrası adet kutusunu temizle
                        }
                        else
                        {
                            MessageBox.Show("Stokta yeterli ürün yok!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Ürün bulunamadı.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen önce ürün ve adet seçiniz.");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            karsilama karsilama = new karsilama();
            karsilama.Show();
        }

        private void filtrelebtn_Click(object sender, EventArgs e)
        {
            string SecilenKadegoriAd=filtrelecb.SelectedItem.ToString();
            using (var db = new E2storeDBEntities())
            {
                var kategori = db.Kategoriler.FirstOrDefault(k => k.KategoriAd == SecilenKadegoriAd);

                if (kategori != null)
                {
                    int KategoriId = kategori.KategoriID;

                    var filtreliUrunler = db.Urunler.Where(u => u.KategoriID == KategoriId).Select(u => new { u.UrunID, u.UrunListesi, u.Adet, u.KategoriID }).ToList();
                        

                    urunlerlistesidgw.DataSource = filtreliUrunler;
                }
                else
                {
                    MessageBox.Show("Seçilen kategori veritabanında bulunamadı.");
                }
            }

        }
    }
}

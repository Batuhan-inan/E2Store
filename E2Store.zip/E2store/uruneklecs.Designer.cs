﻿namespace E2store
{
    partial class urunekle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.eklebtn = new System.Windows.Forms.Button();
            this.urunaditb = new System.Windows.Forms.TextBox();
            this.adettb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ürün Adı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adet:";
            // 
            // eklebtn
            // 
            this.eklebtn.Location = new System.Drawing.Point(61, 119);
            this.eklebtn.Margin = new System.Windows.Forms.Padding(2);
            this.eklebtn.Name = "eklebtn";
            this.eklebtn.Size = new System.Drawing.Size(65, 32);
            this.eklebtn.TabIndex = 2;
            this.eklebtn.Text = "Ekle";
            this.eklebtn.UseVisualStyleBackColor = true;
            this.eklebtn.Click += new System.EventHandler(this.eklebtn_Click);
            // 
            // urunaditb
            // 
            this.urunaditb.Location = new System.Drawing.Point(70, 23);
            this.urunaditb.Margin = new System.Windows.Forms.Padding(2);
            this.urunaditb.Name = "urunaditb";
            this.urunaditb.Size = new System.Drawing.Size(76, 20);
            this.urunaditb.TabIndex = 3;
            // 
            // adettb
            // 
            this.adettb.Location = new System.Drawing.Point(70, 63);
            this.adettb.Margin = new System.Windows.Forms.Padding(2);
            this.adettb.Name = "adettb";
            this.adettb.Size = new System.Drawing.Size(76, 20);
            this.adettb.TabIndex = 4;
            // 
            // urunekle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 245);
            this.Controls.Add(this.adettb);
            this.Controls.Add(this.urunaditb);
            this.Controls.Add(this.eklebtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "urunekle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ürün Ekle";
            this.Load += new System.EventHandler(this.urunekle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button eklebtn;
        private System.Windows.Forms.TextBox urunaditb;
        private System.Windows.Forms.TextBox adettb;
    }
}
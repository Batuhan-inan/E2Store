﻿namespace E2store
{
    partial class urunlerform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.urunlerlistesidgw = new System.Windows.Forms.DataGridView();
            this.satinalbtn = new System.Windows.Forms.Button();
            this.uruneklebtn = new System.Windows.Forms.Button();
            this.stokguncellebtn = new System.Windows.Forms.Button();
            this.urunsilbtn = new System.Windows.Forms.Button();
            this.uruncb = new System.Windows.Forms.ComboBox();
            this.yenilebtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.filtrelecb = new System.Windows.Forms.ComboBox();
            this.filtrelebtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.urunlerlistesidgw)).BeginInit();
            this.SuspendLayout();
            // 
            // urunlerlistesidgw
            // 
            this.urunlerlistesidgw.AllowUserToAddRows = false;
            this.urunlerlistesidgw.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.urunlerlistesidgw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.urunlerlistesidgw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightSkyBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.urunlerlistesidgw.DefaultCellStyle = dataGridViewCellStyle6;
            this.urunlerlistesidgw.EnableHeadersVisualStyles = false;
            this.urunlerlistesidgw.Location = new System.Drawing.Point(32, 51);
            this.urunlerlistesidgw.Margin = new System.Windows.Forms.Padding(2);
            this.urunlerlistesidgw.Name = "urunlerlistesidgw";
            this.urunlerlistesidgw.ReadOnly = true;
            this.urunlerlistesidgw.RowHeadersWidth = 51;
            this.urunlerlistesidgw.RowTemplate.Height = 24;
            this.urunlerlistesidgw.Size = new System.Drawing.Size(303, 291);
            this.urunlerlistesidgw.TabIndex = 0;
            // 
            // satinalbtn
            // 
            this.satinalbtn.Location = new System.Drawing.Point(500, 88);
            this.satinalbtn.Margin = new System.Windows.Forms.Padding(2);
            this.satinalbtn.Name = "satinalbtn";
            this.satinalbtn.Size = new System.Drawing.Size(79, 24);
            this.satinalbtn.TabIndex = 1;
            this.satinalbtn.Text = "Satın Al";
            this.satinalbtn.UseVisualStyleBackColor = true;
            this.satinalbtn.Click += new System.EventHandler(this.satinalbtn_Click);
            // 
            // uruneklebtn
            // 
            this.uruneklebtn.Location = new System.Drawing.Point(393, 210);
            this.uruneklebtn.Margin = new System.Windows.Forms.Padding(2);
            this.uruneklebtn.Name = "uruneklebtn";
            this.uruneklebtn.Size = new System.Drawing.Size(92, 24);
            this.uruneklebtn.TabIndex = 2;
            this.uruneklebtn.Text = "Ürün Ekle";
            this.uruneklebtn.UseVisualStyleBackColor = true;
            this.uruneklebtn.Click += new System.EventHandler(this.uruneklebtn_Click);
            // 
            // stokguncellebtn
            // 
            this.stokguncellebtn.Location = new System.Drawing.Point(393, 169);
            this.stokguncellebtn.Margin = new System.Windows.Forms.Padding(2);
            this.stokguncellebtn.Name = "stokguncellebtn";
            this.stokguncellebtn.Size = new System.Drawing.Size(92, 24);
            this.stokguncellebtn.TabIndex = 3;
            this.stokguncellebtn.Text = "Stok Güncelle";
            this.stokguncellebtn.UseVisualStyleBackColor = true;
            this.stokguncellebtn.Click += new System.EventHandler(this.stokguncellebtn_Click);
            // 
            // urunsilbtn
            // 
            this.urunsilbtn.Location = new System.Drawing.Point(393, 252);
            this.urunsilbtn.Margin = new System.Windows.Forms.Padding(2);
            this.urunsilbtn.Name = "urunsilbtn";
            this.urunsilbtn.Size = new System.Drawing.Size(92, 24);
            this.urunsilbtn.TabIndex = 4;
            this.urunsilbtn.Text = "Ürün Sil";
            this.urunsilbtn.UseVisualStyleBackColor = true;
            this.urunsilbtn.Click += new System.EventHandler(this.urunsilbtn_Click);
            // 
            // uruncb
            // 
            this.uruncb.FormattingEnabled = true;
            this.uruncb.Location = new System.Drawing.Point(393, 92);
            this.uruncb.Margin = new System.Windows.Forms.Padding(2);
            this.uruncb.Name = "uruncb";
            this.uruncb.Size = new System.Drawing.Size(92, 21);
            this.uruncb.TabIndex = 5;
            // 
            // yenilebtn
            // 
            this.yenilebtn.Location = new System.Drawing.Point(10, 3);
            this.yenilebtn.Margin = new System.Windows.Forms.Padding(2);
            this.yenilebtn.Name = "yenilebtn";
            this.yenilebtn.Size = new System.Drawing.Size(56, 19);
            this.yenilebtn.TabIndex = 6;
            this.yenilebtn.Text = "Yenile";
            this.yenilebtn.UseVisualStyleBackColor = true;
            this.yenilebtn.Click += new System.EventHandler(this.yenilebtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(517, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Geri";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // filtrelecb
            // 
            this.filtrelecb.FormattingEnabled = true;
            this.filtrelecb.Location = new System.Drawing.Point(107, 14);
            this.filtrelecb.Name = "filtrelecb";
            this.filtrelecb.Size = new System.Drawing.Size(121, 21);
            this.filtrelecb.TabIndex = 8;
            // 
            // filtrelebtn
            // 
            this.filtrelebtn.Location = new System.Drawing.Point(245, 14);
            this.filtrelebtn.Name = "filtrelebtn";
            this.filtrelebtn.Size = new System.Drawing.Size(75, 23);
            this.filtrelebtn.TabIndex = 9;
            this.filtrelebtn.Text = "Filtrele";
            this.filtrelebtn.UseVisualStyleBackColor = true;
            this.filtrelebtn.Click += new System.EventHandler(this.filtrelebtn_Click);
            // 
            // urunlerform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.filtrelebtn);
            this.Controls.Add(this.filtrelecb);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.yenilebtn);
            this.Controls.Add(this.uruncb);
            this.Controls.Add(this.urunsilbtn);
            this.Controls.Add(this.stokguncellebtn);
            this.Controls.Add(this.uruneklebtn);
            this.Controls.Add(this.satinalbtn);
            this.Controls.Add(this.urunlerlistesidgw);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "urunlerform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ÜRÜNLER";
            this.Load += new System.EventHandler(this.urunlerform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.urunlerlistesidgw)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView urunlerlistesidgw;
        private System.Windows.Forms.Button satinalbtn;
        private System.Windows.Forms.Button uruneklebtn;
        private System.Windows.Forms.Button stokguncellebtn;
        private System.Windows.Forms.Button urunsilbtn;
        private System.Windows.Forms.ComboBox uruncb;
        private System.Windows.Forms.Button yenilebtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox filtrelecb;
        private System.Windows.Forms.Button filtrelebtn;
    }
}
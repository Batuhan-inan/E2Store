﻿using System;
using System.Linq;
using System.Windows.Forms;
using E2store;

namespace E2store
{
    public partial class girisekraniform : Form
    {
        public girisekraniform()
        {
            InitializeComponent();
        }
        public void girişbtn_Click(object sender, EventArgs e)
        {
            string kullaniciadi = kullanıcıadıtb.Text;
            string parola = parolatb.Text;

            if (string.IsNullOrWhiteSpace(kullaniciadi) || string.IsNullOrWhiteSpace(parola))
            {
                MessageBox.Show("Kullanıcı adı veya parola boş bırakılamaz.");
                return;
            }

            try
            {
                using (var db = new E2storeDBEntities())
                {
                   
                    var kullanici= db.Kullanicilar.Select(k=>k.KullaniciAd==kullaniciadi&&k.Parola==parola);

                    if (kullanici != null)
                    {
                        KullaniciOturum.GirisYapanKullaniciAdi = kullaniciadi;
                        karsilama karsilama = new karsilama();
                        this.Hide();
                        karsilama.Show();
                        
                    }
                    else
                    {
                        MessageBox.Show("Giriş başarısız! Kullanıcı adı veya parola hatalı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giriş sırasında hata oluştu:\n" + ex.Message);
            }
        }

        private void girisekraniform_Load(object sender, EventArgs e)
        {
            kullanıcıadıtb.Clear();
            parolatb.Clear();
           
        }
    }
}

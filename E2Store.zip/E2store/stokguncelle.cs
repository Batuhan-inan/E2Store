﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class stokguncelle : Form
    {
        public stokguncelle()
        {
            InitializeComponent();
        }

        private void stokguncelle_Load(object sender, EventArgs e)
        {
            
        }

        private void tamambtn_Click(object sender, EventArgs e)
        {
            int adet = Convert.ToInt32(stokadeditb.Text);
            try
            {
                using (var db= new E2storeDBEntities())
                {
                    var nesne = db.Urunler.FirstOrDefault(s=>s.UrunID==KullaniciOturum.ID);
                    if ( nesne != null )
                    {
                        int yeniAdet = nesne.Adet + adet;

                        if (yeniAdet < 0)
                        {
                            MessageBox.Show("Stok adeti 0'ın altına düşemez!");
                            return;
                        }
                        else
                        {
                            nesne.Adet = yeniAdet;
                            db.SaveChanges();
                            MessageBox.Show("Adet başarıyla güncellendi.");
                            if (this.Owner is urunlerform anaform)
                            {
                                anaform.urunleriyenile();
                            }
                            this.Close();
                        }

                            
                    }
                    else
                    {
                        MessageBox.Show("adet eklenemedi");
                    }
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("veritabanına bağlanılamadı");
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class uygulamalar : Form
    {
        public uygulamalar()
        {
            InitializeComponent();
        }

        private void uygulamalar_Load(object sender, EventArgs e)
        {

        }

        private void googlebtn_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\batu2\\Downloads\\ChromeSetup.exe");//link ya da dosya calıstırır

            karsilama karsilama = new karsilama();
            this.Close();
            karsilama.Show();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            karsilama karsilama = new karsilama();
            karsilama.Show();
        }
    }
}

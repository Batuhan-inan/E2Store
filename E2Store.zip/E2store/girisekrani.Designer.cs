﻿namespace E2store
{
    partial class girisekraniform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.girişbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.kullanıcıadıtb = new System.Windows.Forms.TextBox();
            this.parolatb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // girişbtn
            // 
            this.girişbtn.BackColor = System.Drawing.Color.LightSteelBlue;
            this.girişbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.girişbtn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.girişbtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.girişbtn.Location = new System.Drawing.Point(248, 160);
            this.girişbtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.girişbtn.Name = "girişbtn";
            this.girişbtn.Size = new System.Drawing.Size(85, 38);
            this.girişbtn.TabIndex = 0;
            this.girişbtn.Text = "GİRİŞ";
            this.girişbtn.UseVisualStyleBackColor = false;
            this.girişbtn.Click += new System.EventHandler(this.girişbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "KULLANICI ADI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(130, 112);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "PAROLA";
            // 
            // kullanıcıadıtb
            // 
            this.kullanıcıadıtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kullanıcıadıtb.Location = new System.Drawing.Point(215, 58);
            this.kullanıcıadıtb.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.kullanıcıadıtb.Name = "kullanıcıadıtb";
            this.kullanıcıadıtb.Size = new System.Drawing.Size(156, 23);
            this.kullanıcıadıtb.TabIndex = 3;
            // 
            // parolatb
            // 
            this.parolatb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.parolatb.Location = new System.Drawing.Point(215, 104);
            this.parolatb.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.parolatb.Name = "parolatb";
            this.parolatb.PasswordChar = '*';
            this.parolatb.Size = new System.Drawing.Size(156, 23);
            this.parolatb.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(225, 15);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "GİRİŞ EKRANI";
            // 
            // girisekraniform
            // 
            this.AcceptButton = this.girişbtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Salmon;
            this.ClientSize = new System.Drawing.Size(592, 353);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.parolatb);
            this.Controls.Add(this.kullanıcıadıtb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.girişbtn);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "girisekraniform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "E2STORE";
            this.Load += new System.EventHandler(this.girisekraniform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button girişbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox kullanıcıadıtb;
        private System.Windows.Forms.TextBox parolatb;
        private System.Windows.Forms.Label label3;
    }
}


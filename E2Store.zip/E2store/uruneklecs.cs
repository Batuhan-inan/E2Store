﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class urunekle : Form
    {
        public urunekle()
        {
            InitializeComponent();
        }

        private void eklebtn_Click(object sender, EventArgs e)
        {
            string urunadi = urunaditb.Text;
            int adet=Convert.ToInt32(adettb.Text);
            if (string.IsNullOrWhiteSpace(urunadi))
            {
                MessageBox.Show("Lütfen ürün adı girin.");
                return;
            }
            

            try
            {
                using (var db=new E2storeDBEntities())
                {
                    var urunekle = new Urunler { UrunListesi=urunadi,Adet=adet};
                    db.Urunler.Add(urunekle);
                    db.SaveChanges();
                    if (this.Owner is urunlerform geciciformismi)
                    {
                        geciciformismi.urunleriyenile();
                    }


                    this.Close();
                    
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Ürün veritabanına eklenemedi"+ex.Message);
            }

        }

        private void urunekle_Load(object sender, EventArgs e)
        {

        }
    }
}

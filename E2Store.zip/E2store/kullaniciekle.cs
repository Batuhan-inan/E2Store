﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class kullaniciekle : Form
    {
        public kullaniciekle()
        {
            InitializeComponent();
        }

        private void tamambtn_Click(object sender, EventArgs e)
        {
            string yenikullaniciadi = kullaniciaditb.Text;
            string yeniparola = parolatb.Text;
            if (string.IsNullOrEmpty(yenikullaniciadi)||string.IsNullOrEmpty(yeniparola))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun.");
                return;
                
            }
            else
            {
                try
                {
                    using (var db = new E2storeDBEntities())
                    {
                        var kullanicilar = new Kullanicilar();
                        kullanicilar.KullaniciAd = yenikullaniciadi;
                        kullanicilar.Parola = yeniparola;
                        db.Kullanicilar.Add(kullanicilar);
                        db.SaveChanges();
                        if (this.Owner is kullanicilarform anaform)
                        {
                            anaform.KullanicilariListele(); // Listeyi yenile
                        }
                        this.Close();

                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Ekleme sırasında hata oluştu! " + ex.Message);
                }
            }


                

        }

        private void kullaniciekle_Load(object sender, EventArgs e)
        {

        }
    }
}

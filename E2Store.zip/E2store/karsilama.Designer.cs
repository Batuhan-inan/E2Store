﻿namespace E2store
{
    partial class karsilama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.girisyapankullanicilabel = new System.Windows.Forms.Label();
            this.urunlarbtn = new System.Windows.Forms.Button();
            this.kullanicilarbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.geribtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(128, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(361, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "E2 STORE HOŞGELDİNİZ";
            // 
            // girisyapankullanicilabel
            // 
            this.girisyapankullanicilabel.AutoSize = true;
            this.girisyapankullanicilabel.Location = new System.Drawing.Point(502, 25);
            this.girisyapankullanicilabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.girisyapankullanicilabel.Name = "girisyapankullanicilabel";
            this.girisyapankullanicilabel.Size = new System.Drawing.Size(45, 13);
            this.girisyapankullanicilabel.TabIndex = 1;
            this.girisyapankullanicilabel.Text = "kullanıcı";
            // 
            // urunlarbtn
            // 
            this.urunlarbtn.Location = new System.Drawing.Point(74, 197);
            this.urunlarbtn.Margin = new System.Windows.Forms.Padding(2);
            this.urunlarbtn.Name = "urunlarbtn";
            this.urunlarbtn.Size = new System.Drawing.Size(101, 62);
            this.urunlarbtn.TabIndex = 2;
            this.urunlarbtn.Text = "ÜRÜNLER";
            this.urunlarbtn.UseVisualStyleBackColor = true;
            this.urunlarbtn.Click += new System.EventHandler(this.urunlarbtn_Click);
            // 
            // kullanicilarbtn
            // 
            this.kullanicilarbtn.Location = new System.Drawing.Point(251, 197);
            this.kullanicilarbtn.Margin = new System.Windows.Forms.Padding(2);
            this.kullanicilarbtn.Name = "kullanicilarbtn";
            this.kullanicilarbtn.Size = new System.Drawing.Size(101, 62);
            this.kullanicilarbtn.TabIndex = 3;
            this.kullanicilarbtn.Text = "KULLANICILAR";
            this.kullanicilarbtn.UseVisualStyleBackColor = true;
            this.kullanicilarbtn.Click += new System.EventHandler(this.kullanicilarbtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(432, 197);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 62);
            this.button1.TabIndex = 5;
            this.button1.Text = "UYGULAMALAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // geribtn
            // 
            this.geribtn.Location = new System.Drawing.Point(25, 13);
            this.geribtn.Name = "geribtn";
            this.geribtn.Size = new System.Drawing.Size(75, 23);
            this.geribtn.TabIndex = 6;
            this.geribtn.Text = "Geri";
            this.geribtn.UseVisualStyleBackColor = true;
            this.geribtn.Click += new System.EventHandler(this.geribtn_Click);
            // 
            // karsilama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.geribtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.kullanicilarbtn);
            this.Controls.Add(this.urunlarbtn);
            this.Controls.Add(this.girisyapankullanicilabel);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "karsilama";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "karsilama";
            this.Load += new System.EventHandler(this.karsilama_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label girisyapankullanicilabel;
        private System.Windows.Forms.Button urunlarbtn;
        private System.Windows.Forms.Button kullanicilarbtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button geribtn;
    }
}
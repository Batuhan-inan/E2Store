﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class kullaniciguncelle : Form
    {
        public kullaniciguncelle()
        {
            InitializeComponent();
        }

        private void kullaniciguncelle_Load(object sender, EventArgs e)
        {
            
            
            kullaniciaditbguncelle.Text = KullaniciOturum.SecilenkisiAD;
            Parolatbguncelle.Text=KullaniciOturum.SecilenkisiParola;
        }

        private void tamambtn_Click(object sender, EventArgs e)
        {
            string yenikullaniciadiguncelle=kullaniciaditbguncelle.Text;
            string yeniparolaguncelle = Parolatbguncelle.Text;

            try
            {
                using (var db=new E2storeDBEntities())
                {
                    var guncelle = db.Kullanicilar.FirstOrDefault(k=>k.KullaniciAd==KullaniciOturum.SecilenkisiAD&&k.Parola==KullaniciOturum.SecilenkisiParola);
                    if (guncelle != null)
                    {
                        guncelle.KullaniciAd=yenikullaniciadiguncelle;
                        guncelle.Parola=yeniparolaguncelle;
                        db.SaveChanges();
                        MessageBox.Show("Kullanıcı bilgileri güncellendi.");
                        if (this.Owner is kullanicilarform anaform)
                        {
                            anaform.KullanicilariListele(); // Listeyi yenile
                        }
                        this.Close();

                    }
                    else 
                    {
                        MessageBox.Show("Kullanıcı bulunamadı, güncelleme yapılamadı.");
                    }

                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Veritabanı güncellenirken hata oluştu");
            }

        }
    }
}

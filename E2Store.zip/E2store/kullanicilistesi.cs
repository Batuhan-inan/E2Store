﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2store
{
    public partial class kullanicilarform : Form
    {
        public kullanicilarform()
        {
            InitializeComponent();
        }

        private void kullaniciform_Load(object sender, EventArgs e)
        {
            KullanicilariListele();
           
        }
        public  void KullanicilariListele()
        {
            try
            {
                using (var db = new E2storeDBEntities())
                {
                   

                    var kullanicilar = db.Kullanicilar.Where(k => k.KullaniciAd != "admin").ToList();



                    foreach (var k in kullanicilar)
                    {
                        
                        dataGridView1.DataSource = kullanicilar; //data gride ef ile veritabanından verileri liste seklinde atma
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kullanıcıları listelerken hata oluştu:\n" + ex.Message);
            }
        }

        private void eklebtn_Click(object sender, EventArgs e)
        {
            kullaniciekle kullaniciekle = new kullaniciekle();
            kullaniciekle.Owner = this;
            kullaniciekle.Show();

        }

        private void yenilebtn_Click(object sender, EventArgs e)
        {
            KullanicilariListele();
        }

        private void silbtn_Click(object sender, EventArgs e)
        {
            
            if (dataGridView1.SelectedRows.Count>0)
            {
                string secilen =dataGridView1.SelectedRows[0].Cells["KullaniciAd"].Value.ToString();
                DialogResult onay = MessageBox.Show("Bu kullanıcıyı silmek istediğinize emin misiniz?","Onay",MessageBoxButtons.YesNo);
                if (onay == DialogResult.No) 
                {
                    return;
                }
                else
                {
                     try
                     {
                        using (var db= new E2storeDBEntities())
                        {
                            var silinecek=db.Kullanicilar.FirstOrDefault(k=>k.KullaniciAd==secilen);
                            if (silinecek != null)
                            {
                                db.Kullanicilar.Remove(silinecek);
                                db.SaveChanges();
                                MessageBox.Show("Kullanıcı başarıyla silindi.");
                                KullanicilariListele();
                            }
                            else
                            {
                                MessageBox.Show("Kullanıcı veritabanında bulunamadı.");
                            }
                        }

                     }
                     catch (Exception ex)
                     {
                    MessageBox.Show("Silme sırasında hata oluştu" + ex.Message);
                     }
                }


            }
            else
            {
                MessageBox.Show("Lütfen bir satır seçin.");
            }


               
        }

        public void guncellebtn_Click(object sender, EventArgs e)
        {
            string secilenkullaniciadi;
            string secilenparola;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                 secilenkullaniciadi = dataGridView1.SelectedRows[0].Cells["KullaniciAd"].Value.ToString();
                 secilenparola = dataGridView1.SelectedRows[0].Cells["Parola"].Value.ToString();
                KullaniciOturum.SecilenkisiAD=secilenkullaniciadi;
                KullaniciOturum.SecilenkisiParola=secilenparola;
                kullaniciguncelle kullaniciguncelle=new kullaniciguncelle();
                kullaniciguncelle.Owner = this;
                kullaniciguncelle.Show();

            }
            else
            {
                MessageBox.Show("Lütfen Satır Seçiniz");
            }
            
            

        }

        private void Geribtn_Click(object sender, EventArgs e)
        {
            this.Close();
            karsilama karsilama = new karsilama();

            karsilama.Show();
        }
    }
}

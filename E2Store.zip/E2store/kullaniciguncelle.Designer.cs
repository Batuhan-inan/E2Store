﻿namespace E2store
{
    partial class kullaniciguncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tamambtn = new System.Windows.Forms.Button();
            this.Kullaniciaditb = new System.Windows.Forms.Label();
            this.Parolatb = new System.Windows.Forms.Label();
            this.kullaniciaditbguncelle = new System.Windows.Forms.TextBox();
            this.Parolatbguncelle = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tamambtn
            // 
            this.tamambtn.Location = new System.Drawing.Point(81, 180);
            this.tamambtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tamambtn.Name = "tamambtn";
            this.tamambtn.Size = new System.Drawing.Size(75, 27);
            this.tamambtn.TabIndex = 0;
            this.tamambtn.Text = "Tamam";
            this.tamambtn.UseVisualStyleBackColor = true;
            this.tamambtn.Click += new System.EventHandler(this.tamambtn_Click);
            // 
            // Kullaniciaditb
            // 
            this.Kullaniciaditb.AutoSize = true;
            this.Kullaniciaditb.Location = new System.Drawing.Point(23, 79);
            this.Kullaniciaditb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Kullaniciaditb.Name = "Kullaniciaditb";
            this.Kullaniciaditb.Size = new System.Drawing.Size(67, 13);
            this.Kullaniciaditb.TabIndex = 1;
            this.Kullaniciaditb.Text = "Kullanıcı Adı:";
            // 
            // Parolatb
            // 
            this.Parolatb.AutoSize = true;
            this.Parolatb.Location = new System.Drawing.Point(23, 124);
            this.Parolatb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Parolatb.Name = "Parolatb";
            this.Parolatb.Size = new System.Drawing.Size(40, 13);
            this.Parolatb.TabIndex = 2;
            this.Parolatb.Text = "Parola:";
            // 
            // kullaniciaditbguncelle
            // 
            this.kullaniciaditbguncelle.Location = new System.Drawing.Point(96, 76);
            this.kullaniciaditbguncelle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.kullaniciaditbguncelle.Name = "kullaniciaditbguncelle";
            this.kullaniciaditbguncelle.Size = new System.Drawing.Size(96, 20);
            this.kullaniciaditbguncelle.TabIndex = 3;
            // 
            // Parolatbguncelle
            // 
            this.Parolatbguncelle.Location = new System.Drawing.Point(96, 121);
            this.Parolatbguncelle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Parolatbguncelle.Name = "Parolatbguncelle";
            this.Parolatbguncelle.Size = new System.Drawing.Size(96, 20);
            this.Parolatbguncelle.TabIndex = 4;
            // 
            // kullaniciguncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 282);
            this.Controls.Add(this.Parolatbguncelle);
            this.Controls.Add(this.kullaniciaditbguncelle);
            this.Controls.Add(this.Parolatb);
            this.Controls.Add(this.Kullaniciaditb);
            this.Controls.Add(this.tamambtn);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "kullaniciguncelle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "kullanıcı Güncelle";
            this.Load += new System.EventHandler(this.kullaniciguncelle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tamambtn;
        private System.Windows.Forms.Label Kullaniciaditb;
        private System.Windows.Forms.Label Parolatb;
        private System.Windows.Forms.TextBox kullaniciaditbguncelle;
        private System.Windows.Forms.TextBox Parolatbguncelle;
    }
}
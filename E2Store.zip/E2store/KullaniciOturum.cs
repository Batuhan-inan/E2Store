﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E2store
{
    public static class KullaniciOturum
    {
        public static string GirisYapanKullaniciAdi { get; set; }//form1den kişiyi alıyor karsılamada kullanıyor
        public static string SecilenkisiAD;//
        public static string SecilenkisiParola;
        public static int ID;

    }
}
